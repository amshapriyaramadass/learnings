#
# Example file for HelloWorld
#
def main():
  print("hello world")
print("hello priya")

if __name__ == "__main__":  
    main()