i = 4
d = 4.0
s = 'HackerRank '
# Declare second integer, double, and String variables.
a = int(input())
b = float(input())
c = str(input())
# Read and save an integer, double, and String to your variables.

# Print the sum of both integer variables on a new line.
print( int(i+a) )
# Print the sum of the double variables on a new line.
print( float(b+d))
# Concatenate and print the String variables on a new line
print (str(s)+str(c))
# The 's' variable above should be printed first.