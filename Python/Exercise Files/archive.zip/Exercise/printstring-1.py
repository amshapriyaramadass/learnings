# checking PRint with \ statement
# x= 'Isn\'t,they said'
# print(x)
# print('Isn\'t,they said.')

# s='Firstline.\nSecondline'
#  >>> s
# print(s)
# print('C\host\name')
# print(r'C\host\name')
# print("""\
# Usage: thingy [OPTIONS]
#      -h                        Display this usage message
#      -H hostname               Hostname to connect to
# """)
print (str.format("un"*3) + "ium")

# text = ('Put several strings within parentheses '
#             'to have them joined together.')
# print(text)

